# FS-EXP-9-DOCKER
This repo belongs to University.

A production-ready React application demonstrating Docker multi-stage build optimization.

## Features

- ✅ Multi-stage Docker build
- ✅ Optimized image size (~50-100MB vs 1GB+)
- ✅ Nginx web server for production
- ✅ Security headers configured
- ✅ Gzip compression enabled
- ✅ React Router support
- ✅ Docker Compose ready


## Benefits

1. **Smaller Image Size**: Only production files included
2. **Better Security**: Fewer dependencies = fewer vulnerabilities
3. **Faster Deployment**: Smaller images deploy quicker
4. **Production Optimized**: Nginx configured for static file serving
